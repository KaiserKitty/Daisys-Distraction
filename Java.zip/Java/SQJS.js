const questions = [
    {
        question: "Which one of these is a black hole?",
        answers: ["TON 618", "Kepler 22b", "Stephenson 218"],
        correct: 0
    },
    {
        question: "What are the two main gases that make up the sun?",
        answers: ["Plasma and Hydrogen", "Carbon and Hydrogen", "Hydrogen and Helium"],
        correct: 2
    },
    {
        question: "What is the leading theory for the universe's creation?",
        answers: ["The Big Bang", "The Big Bounce", "The Big Rip"],
        correct: 0
    },
    {
        question: "What planets are next to Earth?",
        answers: ["Jupiter and Mars", "Venus and Mars", "Jupiter and Mercury"],
        correct: 1
    },
    {
        question: "Where are most stars born?",
        answers: ["Black holes", "Nebulae", "Supernova"],
        correct: 1
    }
];

let currentQuestion = 0;
let score = 0;

const questionText = document.getElementById("question");
const buttons = document.querySelectorAll(".answer-btn");
const daisy = document.getElementById("daisy"); // Give your image this ID

function loadQuestion() {

    let q = questions[currentQuestion];

    questionText.textContent = q.question;

    buttons.forEach((button, index) => {
        button.textContent = q.answers[index];

        button.classList.remove("correct");
        button.classList.remove("wrong");

        button.disabled = false;
    });

    // Daisy returns to idle every question
    daisy.src = "src/Daisy blinking (1).gif";
}

loadQuestion();

buttons.forEach((button, index) => {

    button.addEventListener("click", () => {
        console.log("Clicked!");

        const correctAnswer = questions[currentQuestion].correct;

        // Disable all buttons
        buttons.forEach(btn => btn.disabled = true);

        if (index === correctAnswer) {

            button.classList.add("correct");

            score++;

            daisy.src = "src/DD/DD images/happy daisy2.gif";

            const RightAudio = document.getElementById("RightAudio");

            if (RightAudio) {
                RightAudio.play().catch(err => {
                    console.log("Audio autoplay was blocked:", err);
                });
            }

        } else {

            button.classList.add("wrong");

            buttons[correctAnswer].classList.add("correct");

            daisy.src = "src/DD/DD images/annoyed daisy2.gif";

            const WrongAudio = document.getElementById("WrongAudio");

            if (WrongAudio) {
                WrongAudio.play().catch(err => {
                    console.log("Audio autoplay was blocked:", err);
                });
            }
        }

        setTimeout(() => {

            currentQuestion++;

            if (currentQuestion < questions.length) {

                loadQuestion();

            } else {

                endQuiz();

            }

        }, 3000);

    });

});

function endQuiz() {

    buttons.forEach(button => button.style.display = "none");

    if (score >= 3) {

        questionText.textContent =
            "Great job! You got " + score + "/5! Are you sure you are not an astronaut?!";

        daisy.src = "src/DD/DD images/happy daisy2.gif";

        const WinAudio = document.getElementById("WinAudio");

        if (WinAudio) {
            WinAudio.play().catch(err => {
                console.log("Audio autoplay was blocked:", err);
            });
        }

    } else {

        questionText.textContent =
            "You only got " + score + "/5. I want to throw you into space.";

        daisy.src = "src/DD/DD images/mad daisy2.gif";

        const LoseAudio = document.getElementById("LoseAudio");

        if (LoseAudio) {
            LoseAudio.play().catch(err => {
                console.log("Audio autoplay was blocked:", err);
            });
        }
    }

    setTimeout(() => {

        window.location.href = "choosepage.html";

    }, 5000);
}