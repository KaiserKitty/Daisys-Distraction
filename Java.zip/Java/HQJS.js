const questions = [
    {
        question: "What year did the USA gain independence?",
        answers: ["1876", "1778", "1776"],
        correct: 2
    },
    {
        question: "Who was the first President of the USA?",
        answers: ["George Washington", "Abraham Lincoln", "Thomas Jefferson"],
        correct: 0
    },
    {
        question: "Which country was the first to land on the moon?",
        answers: ["Soviet Union", "United States", "China"],
        correct: 1
    },
    {
        question: "In which year did World War II end?",
        answers: ["1945", "1939", "1950"],
        correct: 0
    },
    {
        question: "Which ancient civilisation built the pyramids of Giza?",
        answers: ["Romans", "Greeks", "Egyptians"],
        correct: 2
    }
];

let currentQuestion = 0;
let score = 0;

const questionText = document.getElementById("question");
const buttons = document.querySelectorAll(".answer-btn");
const daisy = document.getElementById("daisy"); // Give your image this ID

function loadQuestion() {

    let q = questions[currentQuestion];

    questionText.textContent = q.question;

    buttons.forEach((button, index) => {
        button.textContent = q.answers[index];

        button.classList.remove("correct");
        button.classList.remove("wrong");

        button.disabled = false;
    });

    // Daisy returns to idle every question
    daisy.src = "src/Daisy blinking (1).gif";
}

loadQuestion();

buttons.forEach((button, index) => {

    button.addEventListener("click", () => {
        console.log("Clicked!");

        const correctAnswer = questions[currentQuestion].correct;

        // Disable all buttons
        buttons.forEach(btn => btn.disabled = true);

        if (index === correctAnswer) {

            button.classList.add("correct");

            score++;

            daisy.src = "src/DD/DD images/happy daisy2.gif";

            const RightAudio = document.getElementById("RightAudio");

            if (RightAudio) {
                RightAudio.play().catch(err => {
                    console.log("Audio autoplay was blocked:", err);
                });
            }

        } else {

            button.classList.add("wrong");

            buttons[correctAnswer].classList.add("correct");

            daisy.src = "src/DD/DD images/annoyed daisy2.gif";

            const WrongAudio = document.getElementById("WrongAudio");

            if (WrongAudio) {
                WrongAudio.play().catch(err => {
                    console.log("Audio autoplay was blocked:", err);
                });
            }
        }

        setTimeout(() => {

            currentQuestion++;

            if (currentQuestion < questions.length) {

                loadQuestion();

            } else {

                endQuiz();

            }

        }, 3000);

    });

});

function endQuiz() {

    buttons.forEach(button => button.style.display = "none");

    if (score >= 3) {

        questionText.textContent =
            "Great job! You got " + score + "/5! You really know your history!";

        daisy.src = "src/DD/DD images/happy daisy2.gif";

        const WinAudio = document.getElementById("WinAudio");

        if (WinAudio) {
            WinAudio.play().catch(err => {
                console.log("Audio autoplay was blocked:", err);
            });
        }

    } else {

        questionText.textContent =
            "You only got " + score + "/5. Not the smartest tool in the shed, are you??";

        daisy.src = "src/DD/DD images/mad daisy2.gif";

        const LoseAudio = document.getElementById("LoseAudio");

        if (LoseAudio) {
            LoseAudio.play().catch(err => {
                console.log("Audio autoplay was blocked:", err);
            });
        }

    }

    setTimeout(() => {

        window.location.href = "choosepage.html";

    }, 5000);
}