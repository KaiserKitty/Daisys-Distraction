document.addEventListener("DOMContentLoaded", () => {

    // -------------------------
    // SETTINGS
    // -------------------------

    const IDLE_GIF = "src/Daisy blinking (1).gif";

    const TALKING_GIF = "src/DD/DD images/Daisy talking.gif";

    const NEXT_PAGE = "choosepage.html";

    // Text speed in milliseconds per character
    const TEXT_SPEED = 40;


    // -------------------------
    // AUDIO
    // -------------------------

    const myAudio = document.getElementById("myAudio");

    if (myAudio) {
        myAudio.play().catch(err => {
            console.log("Audio autoplay was blocked:", err);
        });
    }


    // -------------------------
    // DOOR OVERLAY
    // -------------------------

    const overlay = document.querySelector(".door-overlay");

    if (overlay) {
        overlay.addEventListener("click", () => {
            overlay.classList.add("hidden");
        });
    }


    // -------------------------
    // DAISY + DIALOGUE
    // -------------------------

    const dialogue = [
        "Hello! I'm Daisy! Welcome to my distraction game! Designed to distract you from boredom.",
        "This game is a quiz. I will test you on 3 different topics: history, space, and geography.",
        "One of the things I hate the most is stupidity. It's a fatal flaw that many humans unfortunately possess.",
        "Fear not however! As my quizzes will allow me to see how worthy of a homo sapien you are.",
        "Well then, let's go!"
    ];

    let currentDialogue = 0;
    let typingFinished = false;
    let typingTimer = null;

    const typing = document.getElementById("typing");
    const nextButton = document.getElementById("nextButton");
    const daisyImage = document.getElementById("daisyImage");


    // -------------------------
    // DAISY ANIMATION
    // -------------------------

    function setDaisyTalking(isTalking) {

        if (!daisyImage) return;

        if (isTalking) {
            daisyImage.src = TALKING_GIF;
        } else {
            daisyImage.src = IDLE_GIF;
        }

    }


    // -------------------------
    // TYPEWRITER
    // -------------------------

    function typeText(message) {

        // Stop the previous typewriter if necessary
        if (typingTimer) {
            clearTimeout(typingTimer);
        }

        typing.textContent = "";

        typingFinished = false;

        // Disable button while Daisy is talking
        nextButton.disabled = true;

        nextButton.textContent = "Next ▶";


        // Daisy starts talking
        setDaisyTalking(true);


        let index = 0;


        function type() {

            if (index < message.length) {

                typing.textContent += message[index];

                index++;

                typingTimer = setTimeout(type, TEXT_SPEED);

                return;
            }


            // -------------------------
            // TEXT FINISHED
            // -------------------------

            typingFinished = true;

            nextButton.disabled = false;


            // Daisy stops talking
            // and goes back to idle blinking
            setDaisyTalking(false);


            // Change button to PLAY
            // on the final dialogue
            if (currentDialogue === dialogue.length - 1) {

                nextButton.textContent = "PLAY ▶";

            } else {

                nextButton.textContent = "Next ▶";

            }

        }


        type();

    }


    // -------------------------
    // NEXT / PLAY BUTTON
    // -------------------------

    nextButton.addEventListener("click", () => {

        // Don't allow clicking while
        // the dialogue is still typing
        if (!typingFinished) return;

        const myAudio = document.getElementById("myAudio");

        if (myAudio) {
            myAudio.play().catch(err => {
                console.log("Audio autoplay was blocked:", err);
            });
        }


        // More dialogue remains
        if (currentDialogue < dialogue.length - 1) {

            currentDialogue++;

            typeText(dialogue[currentDialogue]);

        } else {

            // Final dialogue reached.
            // PLAY takes the player
            // to the next HTML page.

            window.location.href = NEXT_PAGE;



        }

    });


    // -------------------------
    // START DIALOGUE
    // -------------------------

    typeText(dialogue[currentDialogue]);

});